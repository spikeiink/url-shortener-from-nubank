package com.useranonimo.myapplication.data

data class OriginalUrlResponse(
    val url: String,
)
